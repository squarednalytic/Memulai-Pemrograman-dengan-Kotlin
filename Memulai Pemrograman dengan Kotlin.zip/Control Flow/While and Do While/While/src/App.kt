// main function
fun main() {
    var counter = 1

    while (counter <= 100){
        println("Hello, World!")
        counter++
    }
}