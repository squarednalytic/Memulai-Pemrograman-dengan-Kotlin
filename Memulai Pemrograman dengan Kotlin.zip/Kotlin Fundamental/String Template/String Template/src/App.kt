// main function
fun main() {
    val name = "Kotlin"
    val old = 19
    print("My name is $name, im $old years old")
}