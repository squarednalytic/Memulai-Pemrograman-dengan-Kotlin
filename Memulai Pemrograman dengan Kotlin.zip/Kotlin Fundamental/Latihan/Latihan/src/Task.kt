fun main() {
    val valueA = 101
    val valueB = 52
    val valueC = 99

    val resultA = calculate(valueA, valueB, valueC)
    val resultB = calculate(valueA, valueB, null)

    println("""
        resultA is $resultA
        resultB is $resultB
    """.trimIndent())
}

fun calculate(valueA: Int, valueB: Int, valueC: Int?): String {
    // TODO 1
    val valC = valueC ?: 50
    val result = valueA + (valueB - valC)
    return generateResult(result)
}

// TODO 2
fun generateResult(result: Int) = "Result is $result"