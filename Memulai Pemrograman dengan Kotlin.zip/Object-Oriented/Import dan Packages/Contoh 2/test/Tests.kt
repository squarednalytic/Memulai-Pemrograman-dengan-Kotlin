import org.junit.Assert
import org.junit.Test

class Test {
    @Test fun testSolution() {
        //TODO: implement your test here
        Assert.assertTrue("Tests not implemented for the task", false)
    }
}